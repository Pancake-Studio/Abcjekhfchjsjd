import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

export const app = initializeApp({
  apiKey: "AIzaSyCcd3rAwF47xZr5ifT6IWcvx6cGOqGSswM",
  authDomain: "oxygen-1-d7067.firebaseapp.com",
  projectId: "oxygen-1-d7067",
  storageBucket: "oxygen-1-d7067.appspot.com",
  messagingSenderId: "380655849300",
  appId: "1:380655849300:web:255b522474efe3d33482c1",
  measurementId: "G-RJPB886R37",
});
export const db = getFirestore(app);
