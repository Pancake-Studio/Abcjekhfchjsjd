"use client";

import LoginForm from "./LoginForm";
import Page from "./Admin";
import { useState, useEffect } from "react";

import * as config from "../../config";

export default function Admin() {
  let [loading, setLoading] = useState<boolean>(true);
  let [loggedIn, setLoggedIn] = useState<string>("");

  useEffect(() => {
    window.localStorage.getItem("logged-in") === config.email
      ? /* @ts-ignore */
        setLoggedIn(window.localStorage.getItem("logged-in"))
      : null;
    setLoading(false);
  }, []);

  if (loading) {
    return (
      <>
        <h1 className={"text-center font-bold text-2xl m-4"}>กำลังโหลด...</h1>
      </>
    );
  }

  return <>{loggedIn.length <= 0 ? <LoginForm /> : <Page />}</>;
}
