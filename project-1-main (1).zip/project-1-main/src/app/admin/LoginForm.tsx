// @ts-nocheck

"use client";

import { useState } from "react";
import clsx from "clsx";
import axios from "axios";
import * as config from "../../config";

export default function Home() {
  let [loading, setLoading] = useState<boolean>(false);
  let [email, setEmail] = useState<string>("");
  let [password, setPassword] = useState<string>("");

  let handleSubmit = () => {
    setLoading(true);
    console.log(name);
    console.log(password);

    if (email !== config.email || password !== config.password) {
      alert("email address or password are incorrect.");
      return setLoading(false);
    }

    window.localStorage.setItem("logged-in", email);
    window.location.href = window.location.href;

    setLoading(false);
  };

  return (
    <>
      <h1 className={"text-center text-2xl font-bold my-4"}>
        ระบบเช็คการทำความสะอาด
      </h1>
      <div className={"container mx-auto my-4 w-[90%]"}>
        <div className={"mb-6"}>
          <label
            htmlFor={"email"}
            className={"block mb-2 text-sm font-medium text-gray-900"}
          >
            Email
          </label>
          <input
            type={"email"}
            id={"email"}
            className={
              "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            }
            placeholder={"jirayu@jirayu.fun"}
            required={true}
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />
        </div>
        <div className={"mb-6"}>
          <label
            htmlFor={"password"}
            className={"block mb-2 text-sm font-medium text-gray-900"}
          >
            Password
          </label>
          <input
            type={"password"}
            id={"password"}
            className={
              "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            }
            placeholder={"******"}
            required={true}
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />
        </div>

        <button
          className={clsx(
            "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center shadow-md",
            loading && "opacity-50"
          )}
          disabled={loading}
          onClick={handleSubmit}
        >
          {loading ? "Loading..." : "Login"}
        </button>
      </div>
    </>
  );
}
