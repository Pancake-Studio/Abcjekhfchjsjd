"use client";

import { useState, useEffect } from "react";
import {
  collection,
  getDocs,
  addDoc,
  deleteDoc,
  doc,
} from "firebase/firestore";
import { db } from "../../lib/firebase";
import clsx from "clsx";

export default function Admin() {
  let [groups, setGroups] = useState<any>([]);
  let [name, setName] = useState<any>("");
  let [loading, setLoading] = useState<any>(false);
  let groupsCollectionRef = collection(db, "groups");
  useEffect(() => {
    updateState();
  }, []);

  async function handleSubmit() {
    await addDoc(groupsCollectionRef, {
      group: name,
    });

    updateState();
  }

  async function removeItem(id: any) {
    let groupDoc = doc(db, "groups", id);
    await deleteDoc(groupDoc);
    updateState();
  }

  async function updateState() {
    let data = await getDocs(groupsCollectionRef);
    setGroups(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
  }

  return (
    <>
      <h1 className={"text-center font-bold text-2xl m-4"}>
        ระบบเช็คการทำความสะอาด
      </h1>
      <hr />
      <p className={"text-xl text-center m-2"}>สร้างกลุ่มใหม่</p>
      <div className={"w-[90%] mx-auto container"}>
        <div className={"mb-6"}>
          <label
            htmlFor={"name"}
            className={"block mb-2 text-sm font-medium text-gray-900"}
          >
            ชื่อของกลุ่ม
          </label>
          <input
            type={"text"}
            id={"name"}
            className={
              "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            }
            placeholder={"กลุ่มใหม่"}
            required={true}
            value={name}
            onChange={(event) => setName(event.target.value)}
          />
        </div>
        <button
          className={clsx(
            "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center shadow-md",
            loading && "opacity-50"
          )}
          disabled={loading}
          onClick={handleSubmit}
        >
          {loading ? "Loading..." : "สร้างกลุ่ม"}
        </button>
      </div>
      <hr className={"my-4"} />
      {groups.length <= 0 ? (
        <h1 className={"text-center"}>ไม่พบกลุ่มที่มีอยู่</h1>
      ) : (
        groups?.map((data: any, index: any) => (
          <div
            className={"text-center cursor-pointer hover:text-rose-500"}
            onClick={() => removeItem(data.id)}
          >
            {data.group}
          </div>
        ))
      )}
    </>
  );
}
