import "./globals.css";

export const metadata = {
  title: "ระบบเช็คการทำความสะอาด",
  description: "ระบบเช็คการทำความสะอาด",
};

export default function RootLayout({ children, session }: any) {
  return (
    <>
      <html lang="th">
        <body>
          {children}
        </body>
      </html>
    </>
  );
}
