// @ts-nocheck

"use client";

import { useState, useEffect } from "react";
import { webhook_url } from "../config";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../lib/firebase";
import clsx from "clsx";
import axios from "axios";

export default function Home() {
  let [loading, setLoading] = useState<boolean>(false);
  let [pageLoading, setPageLoading] = useState<boolean>(true);
  let [detail, setDetail] = useState<string>("");
  let [group, setGroup] = useState<string>("ยังไม่ถูกเลือก");
  let [attachment1, setAttachment1] = useState<any>("");
  let [attachment2, setAttachment2] = useState<any>("");
  let [groups, setGroups] = useState<any>([]);
  let [day, setDay] = useState<string>("1");
  let [month, setMonth] = useState<string>("1");
  let [year, setYear] = useState<string>("1");
  let groupsCollectionRef = collection(db, "groups");

  let handleSubmit = () => {
    setLoading(true);

    axios
      .post(webhook_url, {
        embeds: [
          {
            title: group,
            color: 0xffff00,
            description: `กลุ่ม | ${group}\nรายละเอียด | ${
              detail.length <= 0 ? "ไม่มีข้อมูลเพิ่มเติม" : detail
            }`,
            footer: {
              text: `${day}/${month}/${year}`,
            },
          },
        ],
      })
      .then(() => sendAttachment(attachment1))
      .catch((e) => {
        alert("เกิดข้อผิดพลาดระหว่างส่งข้อความ");
        setLoading(false);
        console.error(e);
      })
      .finally(() => {
        setLoading(false);
        setDetail("");
      });
  };

  let sendAttachment = async (attachment: any) => {
    if (attachment === attachment1) sendAttachment(attachment2);
    // @ts-ignore
    const formData = new FormData();
    // @ts-ignore
    formData.append("file", attachment);

    axios
      /* @ts-ignore */
      .post(webhook_url, formData)
      .then(() => {
        if (attachment === attachment2) alert("ข้อความถูกส่งเรียบร้อยแล้ว!");
      })
      .catch((e) => {
        alert("เกิดข้อผิดพลาดระหว่างส่งข้อความ");
        console.error(e);
      })
      .finally(() => {
        setLoading(false);
        setDetail("");
      });
  };

  // @ts-ignore
  useEffect(async () => {
    let data = await getDocs(groupsCollectionRef);
    setGroups(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })));

    let date = new Date();

    // @ts-ignore
    setDay(date.getDate().toString());
    // @ts-ignore
    setMonth((date.getMonth() + 1).toString());
    // @ts-ignore
    setYear(date.getFullYear().toString());

    setPageLoading(false);
  }, []);

  if (pageLoading) {
    return (
      <>
        <h1 className={"text-center font-bold text-2xl m-4"}>กำลังโหลด...</h1>
      </>
    );
  }

  return (
    <>
      <h1 className={"text-center text-2xl font-bold my-4"}>
        ระบบเช็คการทำความสะอาด
      </h1>
      <div className={"container mx-auto my-4 w-[90%]"}>
        <div className={"mb-6"}>
          <label
            htmlFor={"detail"}
            className={"block mb-2 text-sm font-medium text-gray-900"}
          >
            รายละเอียดเพิ่มเติม
          </label>
          <input
            type={"text"}
            id={"detail"}
            className={
              "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            }
            value={detail}
            onChange={(event) => setDetail(event.target.value)}
          />
        </div>
        <div className={"mb-6"}>
          <label
            htmlFor={"group"}
            className={"block mb-2 text-sm font-medium text-gray-900"}
          >
            กลุ่มทำความสะอาด
          </label>
          <select
            id={"group"}
            className={
              "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            }
            value={group}
            onChange={(event) => setGroup(event.target.value)}
          >
            <option value={"ยังไม่ถูกเลือก"}>ยังไม่ถูกเลือก</option>
            {groups.map((data: any) => (
              <option value={data.group}>{data.group}</option>
            ))}
          </select>
        </div>
        <div className={"mb-6"}>
          <label
            htmlFor={"day"}
            className={"block mb-2 text-sm font-medium text-gray-900"}
          >
            วันที่
          </label>
          <select
            id={"day"}
            className={
              "bg-gray-50 border border-gray-300 text-gray-900 mb-2 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            }
            value={day}
            onChange={(event) => setDay(event.target.value)}
          >
            <option value={"1"}>1</option>
            <option value={"2"}>2</option>
            <option value={"3"}>3</option>
            <option value={"4"}>4</option>
            <option value={"5"}>5</option>
            <option value={"6"}>6</option>
            <option value={"7"}>7</option>
            <option value={"8"}>8</option>
            <option value={"9"}>9</option>
            <option value={"10"}>10</option>
            <option value={"11"}>11</option>
            <option value={"12"}>12</option>
            <option value={"13"}>13</option>
            <option value={"14"}>14</option>
            <option value={"15"}>15</option>
            <option value={"16"}>16</option>
            <option value={"17"}>17</option>
            <option value={"18"}>18</option>
            <option value={"19"}>19</option>
            <option value={"20"}>20</option>
            <option value={"21"}>21</option>
            <option value={"22"}>22</option>
            <option value={"23"}>23</option>
            <option value={"24"}>24</option>
            <option value={"25"}>25</option>
            <option value={"26"}>26</option>
            <option value={"27"}>27</option>
            <option value={"28"}>28</option>
            <option value={"29"}>29</option>
            <option value={"30"}>30</option>
            <option value={"31"}>31</option>
          </select>
          <select
            id={"month"}
            className={
              "bg-gray-50 border border-gray-300 text-gray-900 mb-2 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            }
            value={month}
            onChange={(event) => setMonth(event.target.value)}
          >
            <option value={"1"}>1</option>
            <option value={"2"}>2</option>
            <option value={"3"}>3</option>
            <option value={"4"}>4</option>
            <option value={"5"}>5</option>
            <option value={"6"}>6</option>
            <option value={"7"}>7</option>
            <option value={"8"}>8</option>
            <option value={"9"}>9</option>
            <option value={"10"}>10</option>
            <option value={"11"}>11</option>
            <option value={"12"}>12</option>
          </select>
          <select
            id={"year"}
            className={
              "bg-gray-50 border border-gray-300 text-gray-900 mb-2 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            }
            value={year}
            onChange={(event) => setYear(event.target.value)}
          >
            <option value={"2020"}>2020</option>
            <option value={"2021"}>2021</option>
            <option value={"2022"}>2022</option>
            <option value={"2023"}>2023</option>
            <option value={"2024"}>2024</option>
            <option value={"2025"}>2025</option>
            <option value={"2026"}>2026</option>
            <option value={"2027"}>2027</option>
            <option value={"2028"}>2028</option>
            <option value={"2029"}>2029</option>
            <option value={"2030"}>2030</option>
          </select>
        </div>
        <div className={"mb-6"}>
          <label
            htmlFor={"attachment1"}
            className={"block mb-2 text-sm font-medium text-gray-900"}
          >
            รูปผู้ทำความสะอาด
          </label>
          <input
            type={"file"}
            id={"attachment1"}
            className={
              "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            }
            required={true}
            onChange={(event) => setAttachment1(event.target.files[0])}
          />
        </div>
        <div className={"mb-6"}>
          <label
            htmlFor={"attachment2"}
            className={"block mb-2 text-sm font-medium text-gray-900"}
          >
            รูปหลังทำความสะอาด
          </label>
          <input
            type={"file"}
            id={"attachment2"}
            className={
              "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            }
            required={true}
            onChange={(event) => setAttachment2(event.target.files[0])}
          />
        </div>

        <button
          className={clsx(
            "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center shadow-md",
            loading && "opacity-50"
          )}
          disabled={loading}
          onClick={handleSubmit}
        >
          {loading ? "Loading..." : "ส่งข้อมูล"}
        </button>
      </div>
    </>
  );
}
