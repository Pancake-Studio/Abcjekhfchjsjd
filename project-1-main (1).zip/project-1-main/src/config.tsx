/* For notification */
export const webhook_url: string =
  "https://discord.com/api/webhooks/1095259947035525181/f_4rmvAAEuOGFMF57VrEP3f33GMd-dOdgBIPK6dHcqTIJNMX9_dUgRFWeaAQSv3evqz3";

/* For admin details that use to login */
export const email: string = "admin@oxygen-project.xyz";
export const password: string = "admin@oxygen-auth";
